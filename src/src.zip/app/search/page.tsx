
'use client'
import { useSearchParams } from 'next/navigation'
import { usePosts } from '@/store/usePosts'
import PostCard from '@/components/PostCard'
import Header from '@/components/Header'
import { useMemo } from 'react'

export default function SearchPage(){
  const q = (useSearchParams().get('q') ?? '').toLowerCase()
  const items = usePosts(s=>s.items)
  const filtered = useMemo(()=>{
    if(!q) return items
    return items.filter(p=> p.content.toLowerCase().includes(q))
  },[q, items])
  return (
    <main className="max-w-2xl mx-auto">
      <Header />
      <div aria-live="polite">
        {filtered.map(p=> <PostCard key={p.id} post={p}/>)}
      </div>
    </main>
  )
}
