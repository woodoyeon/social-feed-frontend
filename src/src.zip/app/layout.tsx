
import './globals.css'
import { ThemeProvider } from 'next-themes'
import React from 'react'

export const metadata = {
  title: 'Social Feed — MVP',
  description: '48h social feed challenge (full)'
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html suppressHydrationWarning>
      <body className="bg-white text-slate-900 dark:bg-slate-950 dark:text-slate-50">
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
          {children}
        </ThemeProvider>
      </body>
    </html>
  )
}
