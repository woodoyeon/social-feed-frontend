
import Header from '@/components/Header'
import ComposeForm from '@/components/ComposeForm'

export default function ComposePage(){
  return (
    <main className="max-w-2xl mx-auto">
      <Header />
      <ComposeForm />
    </main>
  )
}
