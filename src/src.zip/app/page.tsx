
import Feed from '@/components/Feed'
import Header from '@/components/Header'

export default function Page(){
  return (
    <main className="max-w-2xl mx-auto">
      <Header />
      <Feed />
    </main>
  )
}
