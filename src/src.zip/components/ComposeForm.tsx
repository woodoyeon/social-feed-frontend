
'use client'
import { useState, useMemo } from 'react'
import { usePosts } from '@/store/usePosts'

export default function ComposeForm(){
  const [text, setText] = useState('')
  const [file, setFile] = useState<File|null>(null)
  const preview = useMemo(()=> file ? URL.createObjectURL(file) : '', [file])
  const prepend = usePosts(s=>s.prepend)

  const remain = 280 - text.length
  const disabled = remain < 0 || text.trim().length===0

  function onSubmit(e:React.FormEvent){
    e.preventDefault()
    const newPost = {
      id: Date.now(),
      author: {
        name: "내 이름", username: "myusername",
        profileImage: "https://picsum.photos/40/40?random=99", verified:false
      },
      content: text, images: preview ? [preview] : [],
      createdAt: new Date().toISOString(),
      likes:0, retweets:0, comments:0, isLiked:false, isRetweeted:false
    }
    prepend(newPost as any)
    setText(''); setFile(null)
  }

  return (
    <form onSubmit={onSubmit} className="p-4 flex flex-col gap-3" aria-label="게시물 작성">
      <textarea
        value={text}
        onChange={e=>setText(e.target.value)}
        placeholder="무슨 일이 일어나고 있나요?"
        className="min-h-28 p-3 rounded border"
        maxLength={280}
        aria-label="게시물 내용"
      />
      <div className="flex items-center justify-between">
        <input type="file" accept="image/*" onChange={e=>setFile(e.target.files?.[0] ?? null)} aria-label="이미지 첨부" />
        <span className={remain<0 ? 'text-red-500' : 'text-slate-500'} aria-live="polite">{remain}</span>
      </div>
      {preview && <img src={preview} alt="미리보기 이미지" className="w-full rounded-lg" />}
      <button disabled={disabled} className="self-end px-4 py-2 rounded bg-blue-600 text-white disabled:opacity-50" aria-disabled={disabled}>
        게시
      </button>
    </form>
  )
}
