
'use client'
import { fromNow } from '@/lib/time'
import { highlight } from '@/lib/parse'
import { usePosts } from '@/store/usePosts'
import type { Post } from '@/lib/api'
import { useState } from 'react'

export default function PostCard({ post }: { post: Post }){
  const like = usePosts(s=>s.like)
  const retweet = usePosts(s=>s.retweet)
  const [anim, setAnim] = useState(false)

  function onLike(){
    setAnim(true)
    setTimeout(()=> setAnim(false), 300)
    like(post.id)
  }

  if(!post) return null
  return (
    <article className="border-b p-4 flex gap-3" role="article">
      <img src={post.author.profileImage} alt={`${post.author.name} 프로필 이미지`} className="size-10 rounded-full"/>
      <div className="flex-1">
        <div className="flex items-center gap-2 text-sm">
          <b>{post.author.name}</b>
          <span className="text-slate-500">@{post.author.username} · {fromNow(post.createdAt)}</span>
        </div>
        <p
          className="mt-1 leading-6"
          dangerouslySetInnerHTML={{ __html: highlight(post.content) }}
        />
        {post.images?.length>0 && (
          <div className="mt-2 rounded-lg overflow-hidden">
            <img src={post.images[0]} alt="게시물 이미지" className="w-full object-cover"/>
          </div>
        )}
        <div className="mt-2 flex gap-6 text-sm text-slate-600">
          <button
            onClick={()=>retweet(post.id)}
            aria-pressed={post.isRetweeted}
            aria-label="리트윗"
            className="hover:opacity-80 focus-visible:outline-2 focus-visible:outline-blue-500"
          >
            🔁 {post.retweets}
          </button>
          <button
            onClick={onLike}
            aria-pressed={post.isLiked}
            aria-label="좋아요"
            className={"relative hover:opacity-80 focus-visible:outline-2 focus-visible:outline-blue-500 " + (anim? "like-pop":"")}
          >
            ♥ {post.likes}
            {anim && <span className="like-spark" aria-hidden="true">+1</span>}
          </button>
          <div aria-label="댓글 수">💬 {post.comments}</div>
        </div>
      </div>
    </article>
  )
}
