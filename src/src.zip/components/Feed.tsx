
'use client'
import { useEffect, useRef } from 'react'
import { useInView } from 'react-intersection-observer'
import { useVirtualizer } from '@tanstack/react-virtual'
import { usePosts } from '@/store/usePosts'
import PostCard from './PostCard'
import { FeedSkeleton } from './Skeletons'

export default function Feed(){
  const { items, loadMore, loading, hasMore, prepend, newCount, clearNew } = usePosts()
  const parentRef = useRef<HTMLDivElement>(null)
  const rowVirtualizer = useVirtualizer({
    count: items.length,
    getScrollElement: ()=> parentRef.current,
    estimateSize: ()=> 180,
    overscan: 6
  })
  const { ref, inView } = useInView({ root: parentRef.current as any })

  useEffect(()=>{ loadMore() },[])
  useEffect(()=>{ if(inView && hasMore && !loading) loadMore() },[inView, hasMore, loading, loadMore])

  // polling
  useEffect(()=>{
    const id = setInterval(()=>{
      const now = new Date().toISOString()
      prepend({
        id: Date.now(),
        author: { name:'Live', username:'live', profileImage:'https://picsum.photos/40/40?random=10' },
        content: '실시간 새 글이 도착했습니다! #live #' + Math.floor(Math.random()*100),
        images: [], createdAt: now, likes:0, retweets:0, comments:0, isLiked:false, isRetweeted:false
      } as any, true)
    }, 12000)
    return ()=> clearInterval(id)
  }, [prepend])

  return (
    <div className="relative">
      {newCount > 0 && (
        <button
          className="absolute left-1/2 -translate-x-1/2 top-2 z-10 px-3 py-1 text-sm rounded-full bg-blue-600 text-white shadow"
          onClick={clearNew}
          aria-live="polite"
        >
          새 게시물 {newCount}개 보기
        </button>
      )}
      <div ref={parentRef} className="h-[calc(100vh-60px)] overflow-auto" role="feed" aria-busy={loading}>
        <div className="relative" style={{ height: rowVirtualizer.getTotalSize() }}>
          {rowVirtualizer.getVirtualItems().map(v=>(
            <div key={v.key} className="absolute left-0 right-0" style={{ transform:`translateY(${v.start}px)`}}>
              <PostCard post={items[v.index]} />
            </div>
          ))}
        </div>

        {loading && <FeedSkeleton/>}
        {hasMore && <div ref={ref} className="h-10"/>}
      </div>
    </div>
  )
}
