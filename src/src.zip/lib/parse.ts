
export function highlight(text:string){
  return text
    .replace(/#(\w+)/g, `<a href="/search?q=%23$1" class="text-blue-500 hover:underline">#$1</a>`)
    .replace(/@(\w+)/g, `<a href="/search?q=%40$1" class="text-blue-500 hover:underline">@$1</a>`)
}
