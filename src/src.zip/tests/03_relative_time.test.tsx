
import { fromNow } from '@/lib/time'
test('상대시간 함수', ()=>{
  const s = fromNow(new Date().toISOString())
  expect(typeof s).toBe('string')
})
