
test('반응형은 스타일로 커버(스모크)', ()=>{
  expect(true).toBeTruthy()
})
