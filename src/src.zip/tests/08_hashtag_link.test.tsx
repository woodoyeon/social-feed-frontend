
import { highlight } from '@/lib/parse'
test('해시태그 하이라이트', ()=>{
  const html = highlight('hello #tag')
  expect(html).toContain('/search?q=%23tag')
})
