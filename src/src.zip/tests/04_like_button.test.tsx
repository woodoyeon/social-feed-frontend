
import PostCard from '@/components/PostCard'
import { render, screen } from '@testing-library/react'
import '@testing-library/jest-dom'
const post:any = {
  id:1, author:{name:'A', username:'a', profileImage:''},
  content:'hello', images:[], createdAt:new Date().toISOString(),
  likes:0, retweets:0, comments:0, isLiked:false, isRetweeted:false
}
jest.mock('@/store/usePosts', ()=> ({ usePosts: (sel:any)=> sel({ like: jest.fn(), retweet: jest.fn() }) }))
test('좋아요 버튼 존재', ()=>{
  render(<PostCard post={post}/>)
  expect(screen.getByLabelText('좋아요')).toBeInTheDocument()
})
