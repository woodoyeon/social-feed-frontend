
import { render } from '@testing-library/react'
import Page from '@/app/page'
test('무한 스크롤 컴포넌트 존재', ()=>{
  render(<Page />)
  expect(true).toBeTruthy()
})
