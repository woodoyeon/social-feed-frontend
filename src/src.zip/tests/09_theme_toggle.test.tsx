
import { render } from '@testing-library/react'
import Header from '@/components/Header'
test('다크모드 토글 렌더', ()=>{
  render(<Header />)
  expect(true).toBeTruthy()
})
