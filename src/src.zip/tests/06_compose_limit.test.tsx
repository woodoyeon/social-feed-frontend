
import { render, screen, fireEvent } from '@testing-library/react'
import ComposePage from '@/app/compose/page'
test('280자 제한 카운터 표시', ()=>{
  render(<ComposePage />)
  const textarea = screen.getByLabelText('게시물 내용')
  fireEvent.change(textarea, { target:{ value:'a'.repeat(281) }})
  expect(screen.getByText(/-1/)).toBeInTheDocument()
})
