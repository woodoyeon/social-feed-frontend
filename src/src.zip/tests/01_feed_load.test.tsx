
import { render, screen } from '@testing-library/react'
import Page from '@/app/page'
import '@testing-library/jest-dom'
test('피드 페이지 렌더', ()=>{
  render(<Page />)
  expect(screen.getByText('Feed')).toBeInTheDocument()
})
