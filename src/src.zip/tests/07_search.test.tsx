
import { render } from '@testing-library/react'
import SearchPage from '@/app/search/page'
test('검색 페이지 렌더', ()=>{
  render(<SearchPage /> as any)
  expect(true).toBeTruthy()
})
