
import { create } from 'zustand'
import { fetchPosts, toggleLike, toggleRetweet, type Post } from '@/lib/api'
import { saveCache, loadCache } from '@/utils/cache'

type State = {
  items: Post[]
  page: number
  hasMore: boolean
  loading: boolean
  newCount: number
  loadMore: () => Promise<void>
  prepend: (p: Post, markNew?: boolean)=>void
  like: (id:number)=>Promise<void>
  retweet: (id:number)=>Promise<void>
  reset: ()=>void
  clearNew: ()=>void
}

const CACHE_KEY = 'feed_cache_v1'

export const usePosts = create<State>((set, get)=>({
  items: [], page: 1, hasMore: true, loading: false, newCount: 0,
  async loadMore(){
    const { page, items, loading, hasMore } = get()
    if(loading || !hasMore) return
    set({loading:true})
    try{
      const batch = await fetchPosts(page, 10)
      const merged = [...items, ...batch]
      set({
        items: merged,
        page: page+1,
        hasMore: batch.length > 0,
        loading: false
      })
      saveCache(CACHE_KEY, merged)
    }catch(e){
      const cached = loadCache<Post[]>(CACHE_KEY)
      if(cached){
        set({ items: cached, loading:false, hasMore:false })
      }else{
        set({ loading:false })
      }
    }
  },
  prepend(p, markNew=false){
    set(s=>({items:[p, ...s.items], newCount: markNew ? s.newCount + 1 : s.newCount }))
  },
  async like(id){
    set(s=>({items: s.items.map(p=> p.id===id ? {
      ...p, isLiked: !p.isLiked, likes: p.isLiked? p.likes-1 : p.likes+1
    }:p)}))
    const res = await toggleLike(id)
    if(!res.success){
      set(s=>({items: s.items.map(p=> p.id===id ? {
        ...p, isLiked: !p.isLiked, likes: p.isLiked? p.likes-1 : p.likes+1
      }:p)}))
    }
  },
  async retweet(id){
    set(s=>({items: s.items.map(p=> p.id===id ? {
      ...p, isRetweeted: !p.isRetweeted, retweets: p.isRetweeted? p.retweets-1 : p.retweets+1
    }:p)}))
    const res = await toggleRetweet(id)
    if(!res.success){
      set(s=>({items: s.items.map(p=> p.id===id ? {
        ...p, isRetweeted: !p.isRetweeted, retweets: p.isRetweeted? p.retweets-1 : p.retweets+1
      }:p)}))
    }
  },
  reset(){ set({items:[], page:1, hasMore:true, newCount:0}) },
  clearNew(){ set(s=>({ newCount: 0 })) }
}))
